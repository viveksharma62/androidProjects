<?php
require_once 'functions.php';

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "Invalid email address.";
    } else {
        if (unsubscribeEmail($email)) {
            $message = "Successfully unsubscribed $email.";
        } else {
            $message = "Email not found or could not be removed.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Unsubscribe from XKCD Updates</title>
</head>
<body>
    <h1>Unsubscribe</h1>

    <?php if (!empty($message)): ?>
        <p><strong><?php echo htmlspecialchars($message); ?></strong></p>
    <?php endif; ?>

    <form method="POST">
        <label>Email:
            <input type="email" name="email" required>
        </label><br><br>
        <button type="submit">Unsubscribe</button>
    </form>
</body>
</html>
