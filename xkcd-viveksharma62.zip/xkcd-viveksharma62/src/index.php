<?php
require_once 'functions.php';

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $code = $_POST['code'] ?? '';

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "Invalid email address.";
    } elseif (empty($code)) {
        // Step 1: Generate and send verification code
        $verificationCode = generateVerificationCode();
        // Store code temporarily in a file
        file_put_contents(__DIR__ . "/verif_codes/$email.txt", $verificationCode);

        if (sendVerificationEmail($email, $verificationCode)) {
            $message = "Verification code sent to $email.";
        } else {
            $message = "Failed to send verification code.";
        }
    } else {
        // Step 2: Check verification code
        $storedCodeFile = __DIR__ . "/verif_codes/$email.txt";
        if (file_exists($storedCodeFile)) {
            $storedCode = trim(file_get_contents($storedCodeFile));

            if ($code === $storedCode) {
                if (registerEmail($email)) {
                    unlink($storedCodeFile); // remove temp file
                    $message = "Email registered successfully!";
                } else {
                    $message = "Failed to register email.";
                }
            } else {
                $message = "Incorrect verification code.";
            }
        } else {
            $message = "No verification code found. Please request again.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Email Registration</title>
</head>
<body>
    <h1>Register Your Email</h1>

    <?php if (!empty($message)): ?>
        <p><strong><?php echo htmlspecialchars($message); ?></strong></p>
    <?php endif; ?>

    <form method="POST">
        <label>Email: <input type="email" name="email" required></label><br><br>

        <label>Verification Code (only if received): <input type="text" name="code"></label><br><br>

        <button type="submit">Submit</button>
    </form>
</body>
</html>