#!/bin/bash

# Absolute path to PHP and the cron.php script
PHP_BIN=$(which php)
SCRIPT_PATH="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/cron.php"

# CRON expression: Every 5 minutes
CRON_JOB="*/5 * * * * $PHP_BIN $SCRIPT_PATH >/dev/null 2>&1"

# Check if the job is already in the crontab
(crontab -l 2>/dev/null | grep -F "$SCRIPT_PATH") >/dev/null

if [ $? -eq 0 ]; then
  echo "CRON job already exists. No changes made."
else
  # Add the new cron job
  (crontab -l 2>/dev/null; echo "$CRON_JOB") | crontab -
  echo "CRON job added to run every 5 minutes."
fi
