<?php

/**
 * Generate a 6-digit numeric verification code.
 */
function generateVerificationCode(): string {
    return str_pad(strval(rand(0, 999999)), 6, '0', STR_PAD_LEFT);
}

/**
 * Send a verification code to an email.
 */
function sendVerificationEmail(string $email, string $code): bool {
    $subject = "Your Verification Code";
    $message = "Your verification code is: $code";
    $headers = "From: no-reply@example.com";

    // NOTE: This will only work if mail() is properly configured
    return mail($email, $subject, $message, $headers);
}

/**
 * Register an email by storing it in a file.
 */
function registerEmail(string $email): bool {
    $file = __DIR__ . '/registered_emails.txt';
    $emails = file_exists($file) ? file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) : [];

    if (!in_array($email, $emails)) {
        return file_put_contents($file, $email . PHP_EOL, FILE_APPEND | LOCK_EX) !== false;
    }

    return true; // Already registered
}

/**
 * Unsubscribe an email by removing it from the list.
 */
function unsubscribeEmail(string $email): bool {
    $file = __DIR__ . '/registered_emails.txt';

    if (!file_exists($file)) return false;

    $emails = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $updatedEmails = array_filter($emails, fn($e) => trim($e) !== trim($email));

    return file_put_contents($file, implode(PHP_EOL, $updatedEmails) . PHP_EOL, LOCK_EX) !== false;
}

/**
 * Fetch random XKCD comic and format data as HTML.
 */
function fetchAndFormatXKCDData(): string {
    $randomComicNum = rand(1, 2800); // XKCD comics are currently around 2800
    $url = "https://xkcd.com/$randomComicNum/info.0.json";

    $json = @file_get_contents($url);
    if ($json === false) return "<p>Could not fetch XKCD comic.</p>";

    $data = json_decode($json, true);
    $title = htmlspecialchars($data['title']);
    $img = htmlspecialchars($data['img']);
    $alt = htmlspecialchars($data['alt']);

    return "<h2>$title</h2><img src=\"$img\" alt=\"$alt\" /><p>$alt</p>";
}

/**
 * Send the formatted XKCD updates to registered emails.
 */
function sendXKCDUpdatesToSubscribers(): void {
    $file = __DIR__ . '/registered_emails.txt';
    if (!file_exists($file)) return;

    $emails = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $comicHtml = fetchAndFormatXKCDData();

    foreach ($emails as $email) {
        $subject = "Your Daily XKCD Comic";
        $headers = "From: no-reply@example.com\r\nContent-type: text/html; charset=UTF-8";
        mail($email, $subject, $comicHtml, $headers);
    }
}
