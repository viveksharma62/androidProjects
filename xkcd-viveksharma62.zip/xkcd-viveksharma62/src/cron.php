<?php
require_once 'functions.php';

// Call the function to send XKCD comic to all subscribers
sendXKCDUpdatesToSubscribers();

echo "XKCD updates have been sent to all registered emails.";
